package com.categorymanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CategoryManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.categorymanagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.categorymanagement.common.NoSuchElementException;
import com.categorymanagement.common.NotFoundException;
import com.categorymanagement.entity.Category;
import com.categorymanagement.entity.Products;
import com.categorymanagement.repository.CategoryRepository;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Service
@NoArgsConstructor
@AllArgsConstructor
public class CategoryService {

	@Autowired
	private CategoryRepository categoryRepository;

	public List<Category> getAllCategories() throws Exception{
		return categoryRepository.findAll();
	}

	public Category getCategoryById(Long categoryId) {
		Optional<Category> category = categoryRepository.findById(categoryId);
		if (category.isEmpty()) {
			throw new NoSuchElementException("Category with id " + categoryId + " not found");
		}
		return category.get();
	}

	public Category saveCategory(Category category) {
		return categoryRepository.save(category);
	}

	public Category deleteCategory(Long categoryId) {
		Optional<Category> category = categoryRepository.findById(categoryId);
		if (category != null) {
			categoryRepository.deleteById(categoryId);
		} else {
			throw new NotFoundException("Category with givenid is not present");
		}
		return category.get();
	}

	public Category updateCategory(Category category) {
		Category existingCategory = categoryRepository.findById(category.getId()).orElse(null);
		category.setId(existingCategory.getId());
		return categoryRepository.save(category);
	}
}

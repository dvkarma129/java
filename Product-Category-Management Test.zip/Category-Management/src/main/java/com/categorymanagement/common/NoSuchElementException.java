package com.categorymanagement.common;

public class NoSuchElementException extends RuntimeException {

    public NoSuchElementException(String message) {
        super(message);
    }
}

package com.categorymanagement.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.message.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.categorymanagement.common.DuplicateFoundException;
import com.categorymanagement.common.ImageUtils;
import com.categorymanagement.common.NoSuchElementException;
import com.categorymanagement.common.NotFoundException;
import com.categorymanagement.entity.Category;
import com.categorymanagement.entity.Products;
import com.categorymanagement.repository.CategoryRepository;
import com.categorymanagement.repository.ProductRepository;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Service
@AllArgsConstructor
@NoArgsConstructor
public class ProductService {

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private CategoryRepository categoryRepository;

	public List<Products> getAllProducts() {
		 return productRepository.findAll();
	}

	public Products getProductById(long id) {
		Optional<Products> products = productRepository.findById(id);
		if (products.isEmpty()) {
			throw new NoSuchElementException("Product with id " + id + " is not present");
		}
		return products.get();
	}

	public Products addProduct(Products model) {
		Products newProducts = productRepository.findByTitleAndBrand(model.getTitle(),model.getBrand());
		if (newProducts == null) {
			productRepository.save(model);
		} else {
			throw new DuplicateFoundException("Product already exist");
		}
		return model;
	}

	public void deleteProduct(Long id) {
		if (!productRepository.existsById(id)) {
			throw new NoSuchElementException("Product with id " + id + " is not present");
		}
		productRepository.deleteById(id);			
	}

	public Products updateProduct(Long id, Products model) {
		Optional<Products> product = productRepository.findById(id);
		model.setId(id);
		return productRepository.save(model);
	}

	public String uploadImage(MultipartFile file, Long pId) throws IOException {
		Products products = productRepository.findById(pId).get();
		if(products != null) {
			products.setId(pId);
			Products products2 = Products.builder().image(ImageUtils.compressImage(file.getBytes())).build();
			products.setImage(products2.getImage());
			productRepository.save(products);
			return "Uploaded";
		}
		throw new NoSuchElementException("Product with id " + pId + " is not present");
	}

	public byte[] downloadImage(Long pId) {
		Optional<Products> dbImageData = productRepository.findById(pId);
		if (dbImageData != null) {
			byte[] images = ImageUtils.decompressImage(dbImageData.get().getImage());
			return images;			
		}
		throw new NoSuchElementException("Image of product with id " + pId + " is not present");
	}
}

package com.categorymanagement.common;

import org.springframework.http.HttpStatus;

import lombok.Data;

@Data
public class CustomException {

	private final String message;
	private final Throwable throwable;
	private final HttpStatus httpStatus;
	public CustomException(String message, Throwable throwable, HttpStatus httpStatus) {
		super();
		this.message = message;
		this.throwable = throwable;
		this.httpStatus = httpStatus;
	}	
}

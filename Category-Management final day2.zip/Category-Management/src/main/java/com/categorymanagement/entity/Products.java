package com.categorymanagement.entity;

import java.util.List;

import org.hibernate.validator.constraints.UniqueElements;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.Data;

@Entity
@Data
@Table(name = "Products")
public class Products {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long productId;

    @NotBlank(message = "Product title is required")
    private String productTitle;

    @NotBlank(message = "Product description is required")
    private String productDescription;

    @NotNull(message = "Product quantity is required")
    @PositiveOrZero(message = "Product quantity must be a positive or zero value")
    private Long productQty;

    @NotNull(message = "Product price is required")
    @Positive(message = "Product price must be a positive value")
    private Double productPrice;

    @NotBlank(message = "Product brand is required")
    private String productBrand;

    @NotBlank(message = "Product SKU is required")
    @Column(unique = true)
    @Pattern(regexp = "^[a-zA-Z0-9]{0,9}", message = "Product SKU must be alphanumeric")
    private String productSKU;

    @NotBlank(message = "Product picture URL is required")
    private String productPicture;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "product_id", referencedColumnName = "productId")
    private List<Category> categories;
}

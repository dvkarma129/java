package criteriaprac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CriteriaPracApplication {

	public static void main(String[] args) {
		SpringApplication.run(CriteriaPracApplication.class, args);
	}

}

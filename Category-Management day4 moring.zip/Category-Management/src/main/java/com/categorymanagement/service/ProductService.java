package com.categorymanagement.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.apache.logging.log4j.message.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.categorymanagement.common.DuplicateFoundException;
import com.categorymanagement.common.ImageUtils;
import com.categorymanagement.common.NoSuchElementException;
import com.categorymanagement.common.NotFoundException;
import com.categorymanagement.entity.Category;
import com.categorymanagement.entity.Products;
import com.categorymanagement.repository.CategoryRepository;
import com.categorymanagement.repository.ProductRepository;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Service
@AllArgsConstructor
@NoArgsConstructor
public class ProductService {

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private CategoryRepository categoryRepository;

	@Autowired
	private CategoryService categoryService;

	public List<Products> getAllProducts() {
		return productRepository.findAll();
	}

	public Products getProductById(long id) {
		Optional<Products> products = productRepository.findById(id);
		if (products.isEmpty()) {
			throw new NoSuchElementException("Product with id " + id + " is not present");
		}
		return products.get();
	}

//	public Products addProduct(Products model) {
//		Products newProducts = productRepository.findByTitleAndBrand(model.getTitle(),model.getBrand());
//		if (newProducts == null) {
//			productRepository.save(model);
//		} else {
//			throw new DuplicateFoundException("Product already exist");
//		}
//		return model;
//	}

//	public Products addProduct(Products product) {
//
//		List<Category> listCate = new ArrayList<>();
//
//		for (Category category : product.getCategories()) {
//			Category managedCategory = categoryService.getCategoryById(category.getId());
//			Category newCate = new Category();
//			newCate.setSubCategory(managedCategory.getSubCategory());
//			newCate.setDescription(managedCategory.getDescription());
//			newCate.setParentCategory(managedCategory.getParentCategory());
//			newCate.setUrl(managedCategory.getUrl());
//			
//			listCate.add(newCate);
//		}
//
//		product.setCategories(listCate);
//		return productRepository.save(product);
//	}

	public Products addProduct(Products product) {

		Set<Category> setCate = new HashSet<>();

		for (Category category : product.getCategories()) {
			Category checkCate = categoryService.getCategoryById(category.getId());
			Category newCate = new Category();
			newCate.setSubCategory(checkCate.getSubCategory());
			newCate.setDescription(checkCate.getDescription());
			newCate.setParentCategory(checkCate.getParentCategory());
			newCate.setUrl(checkCate.getUrl());

			setCate.add(newCate);
		}
		List<Category> listCate = new ArrayList<>(setCate);
		product.setCategories(listCate);
		
		return productRepository.save(product);
	}

	public void deleteProduct(Long id) {
		if (!productRepository.existsById(id)) {
			throw new NoSuchElementException("Product with id " + id + " is not present");
		}
		productRepository.deleteById(id);
	}

	public Products updateProduct(Long id, Products model) {
		Products existPro = getProductById(id);
		
		        existPro.setTitle(model.getTitle());
		        existPro.setDescription(model.getDescription());
		        existPro.setQuantity(model.getQuantity());
		        existPro.setPrice(model.getPrice());
		        existPro.setBrand(model.getBrand());
		        existPro.setSku(model.getSku());
		        existPro.setCategories(model.getCategories());
		
		        Products updatedProduct = addProduct(existPro);
		        
		        return updatedProduct;
	}

	public String uploadImage(MultipartFile file, Long pId) throws IOException {
		Products products = productRepository.findById(pId).get();
		if (products != null) {
			products.setId(pId);
			Products products2 = Products.builder().image(ImageUtils.compressImage(file.getBytes())).build();
			products.setImage(products2.getImage());
			productRepository.save(products);
			return "Uploaded";
		}
		throw new NoSuchElementException("Product with id " + pId + " is not present");
	}

	public byte[] downloadImage(Long pId) {
		Optional<Products> dbImageData = productRepository.findById(pId);
		if (dbImageData != null) {
			byte[] images = ImageUtils.decompressImage(dbImageData.get().getImage());
			return images;
		}
		throw new NoSuchElementException("Image of product with id " + pId + " is not present");
	}
	

	public List<Products> saveMultipleProducts(List<Products> model) {		
		return productRepository.saveAll(model);
	}

	public void deleteAllPro() {
		productRepository.deleteAll();
	}
	
	public List<Products> findProduct(String proName) {
		return productRepository.findProductsLike(proName);
	}

	public Products findProductBySKU(String sku) {
		return productRepository.findBySku(sku);
	}
}

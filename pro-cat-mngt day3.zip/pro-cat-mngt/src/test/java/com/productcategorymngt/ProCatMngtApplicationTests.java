package com.productcategorymngt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProCatMngtApplicationTests {

	@Test
	void contextLoads() {
	}

}

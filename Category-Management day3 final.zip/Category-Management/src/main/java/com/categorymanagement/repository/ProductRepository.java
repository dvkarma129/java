package com.categorymanagement.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.categorymanagement.entity.Products;

public interface ProductRepository extends JpaRepository<Products, Long>{

	Products findByTitleAndBrand(String title, String brand);
	
}

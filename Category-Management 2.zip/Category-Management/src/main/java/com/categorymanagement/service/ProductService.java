package com.categorymanagement.service;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.categorymanagement.common.ImageUtils;
import com.categorymanagement.entity.Products;
import com.categorymanagement.repository.ProductRepository;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Service
@AllArgsConstructor
@NoArgsConstructor
public class ProductService {

	@Autowired
	private ProductRepository productRepository;

	public List<Products> getAllProducts() {
		List<Products> products = productRepository.findAll();
		if (products == null) {
			return null;
		}
		return products;
	}

	public Products getProductById(long id) {
		Optional<Products> products = productRepository.findById(id);
		return products.get();
	}

	public Products addProduct(Products model) {
		return productRepository.save(model);
	}

	public void deleteProduct(Long id) {
		productRepository.deleteById(id);
	}

	public Products updateProduct(Long id, Products model) {
		Optional<Products> product = productRepository.findById(id);
		model.setProductId(id);
		return productRepository.save(model);
	}

}
